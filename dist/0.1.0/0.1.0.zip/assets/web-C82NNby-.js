import{W as n}from"./index-LlFiDuCm.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
